<?php

namespace App\Http\Controllers\CustomerOrdering;

use App\Enums\RestaurantServiceType;
use App\Http\Controllers\Controller;
use App\Http\Requests\CustomerOrdering\StoreCustomerMenuOrderRequest;
use App\Models\Employee;
use App\Models\Location;
use App\Models\Order;
use App\Models\RestaurantMenuItem;
use App\Models\RestaurantTable;
use App\Models\SystemSetting;
use App\Services\ModuleService;
use App\Services\Restaurant\CustomerOrderingService;
use App\Services\Restaurant\CustomerOrderStatusService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\View\View;

class CustomerMenuController extends Controller
{
    public function __construct(
        private readonly CustomerOrderingService $ordering,
        private readonly CustomerOrderStatusService $orderStatus,
        private readonly ModuleService $modules
    ) {
    }

    public function show(Request $request, Location $location): View
    {
        $this->assertMenuAvailable($location);

        $showUnavailable = (bool) SystemSetting::get(
            'customer_menu_show_unavailable',
            false
        );

        $categoryColumns = ['id', 'name', 'name_ar'];

        if (Schema::hasColumn('categories', 'icon_key')) {
            $categoryColumns[] = 'icon_key';
        }

        if (Schema::hasColumn('categories', 'icon_color')) {
            $categoryColumns[] = 'icon_color';
        }

        $menuQuery = RestaurantMenuItem::query()
            ->forQr((int) $location->id)
            ->whereHas('product', fn ($query) => $query->active())
            ->with([
                'product.category' => fn ($query) => $query
                    ->select($categoryColumns),
                'product.locationProducts' => fn ($query) => $query
                    ->where('location_id', $location->id),
            ])
            ->orderBy('sort_order')
            ->orderBy('id');

        if (! $showUnavailable) {
            $menuQuery->whereHas(
                'product.locationProducts',
                fn ($query) => $query
                    ->where('location_id', $location->id)
                    ->where('is_available', true)
            );
        }

        $menuItems = $menuQuery
            ->limit(250)
            ->get()
            ->map(function (RestaurantMenuItem $menuItem) use ($location): array {
                $product = $menuItem->product;
                $locationProduct = $product?->locationProducts->first();

                return [
                    'menu_item_id' => (int) $menuItem->id,
                    'product_id' => (int) $product->id,
                    'name' => $menuItem->displayName(),
                    'description' => trim(
                        (string) ($menuItem->effectiveDescription() ?? '')
                    ),
                    'image' => $this->assetFromPath(
                        $menuItem->effectiveImage()
                    ),
                    'category_id' => $product->category?->id,
                    'category' => $product->category?->name_ar
                        ?: $product->category?->name
                        ?: 'أخرى',
                    'category_icon' => $product->category?->icon_key
                        ?: $this->guessCategoryIcon(
                            $product->category?->name_ar
                            ?: $product->category?->name
                            ?: 'أخرى'
                        ),
                    'category_icon_color' => $product->category?->icon_color
                        ?: '#111111',
                    'sku' => $product->sku,
                    'price' => (float) $product->getEffectivePriceForLocation(
                        (int) $location->id
                    ),
                    'available' => (bool) (
                        $locationProduct?->is_available ?? false
                    ),
                    'delivery_available' => (bool) $menuItem->show_in_delivery,
                ];
            })
            ->values();

        $categories = $menuItems
            ->filter(fn (array $item): bool => filled($item['category']))
            ->map(fn (array $item): array => [
                'id' => $item['category_id'],
                'name' => $item['category'],
                'icon' => $item['category_icon'] ?? 'sparkles',
                'color' => $item['category_icon_color'] ?? '#111111',
            ])
            ->unique(fn (array $category): string =>
                (string) ($category['id'] ?? $category['name'])
            )
            ->values();

        $tables = $this->tableOptions($location);

        $selectedTable = $this->resolveSelectedTable(
            $tables,
            (string) $request->query('table', '')
        );

        return view('customer-menu.show', [
            'location' => $location,
            'menuItems' => $menuItems,
            'categories' => $categories,
            'tables' => $tables,
            'selectedTable' => $selectedTable,
            'branding' => $this->branding(),
            'theme' => $this->theme(),
            'requestToken' => (string) Str::uuid(),
            'serviceOptions' => $this->serviceOptions(),
            'team' => $this->teamMembers($location),
        ]);
    }

    public function tables(Location $location): JsonResponse
    {
        $this->assertMenuAvailable($location);

        return response()
            ->json([
                'tables' => $this->tableOptions($location)->values()->all(),
                'updated_at' => now()->toIso8601String(),
            ])
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache');
    }

    public function myOrders(Location $location): View
    {
        $this->assertMenuAvailable($location);

        return view('customer-menu.my-orders', [
            'location' => $location,
            'branding' => $this->branding(),
            'theme' => $this->theme(),
        ]);
    }

    public function store(
        StoreCustomerMenuOrderRequest $request,
        Location $location
    ): JsonResponse {
        $this->assertMenuAvailable($location);

        $order = $this->ordering->create(
            $location,
            $request->validated()
        );

        return response()->json([
            'ok' => true,
            'message' => 'تم استلام طلبك بنجاح.',
            'order_number' => $order->order_number,
            'order_id' => (int) $order->id,
            'public_token' => (string) $order->public_token,
            'created_at' => $order->created_at?->toIso8601String(),
            'location' => [
                'id' => (int) $location->id,
                'name' => (string) $location->name,
                'code' => (string) $location->code,
            ],
            'track_url' => route(
                'customer-menu.track',
                ['token' => $order->public_token]
            ),
        ], 201);
    }

    public function track(string $token): View
    {
        $order = $this->publicOrder($token);

        return view('customer-menu.track', [
            'order' => $order,
            'branding' => $this->branding(),
            'theme' => $this->theme(),
            'statusPayload' => $this->orderStatus->payload($order),
        ]);
    }

    public function status(string $token): JsonResponse
    {
        $order = $this->publicOrder($token);

        return response()
            ->json($this->orderStatus->payload($order))
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache')
            ->header('Expires', '0');
    }

    private function assertMenuAvailable(Location $location): void
    {
        abort_unless(
            $this->modules->isEnabled('restaurant'),
            404
        );

        abort_unless(
            $location->is_active && $location->isBranch(),
            404
        );

        abort_unless(
            (bool) SystemSetting::get(
                'customer_menu_enabled',
                true
            ),
            404
        );
    }

    private function publicOrder(string $token): Order
    {
        return Order::query()
            ->where('order_source', 'customer_menu')
            ->where('public_token', $token)
            ->with([
                'location',
                'customer',
                'items',
                'restaurantTable.area',
            ])
            ->firstOrFail();
    }

    private function tableOptions(Location $location): Collection
    {
        return RestaurantTable::query()
            ->forLocation((int) $location->id)
            ->active()
            ->with([
                'area:id,name',
                'activeSession',
            ])
            ->orderBy('area_id')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get()
            ->map(function (RestaurantTable $table): array {
                $occupied = $table->activeSession !== null;

                return [
                    'id' => (int) $table->id,
                    'code' => (string) ($table->code ?? ''),
                    'name' => (string) $table->displayName(),
                    'area' => (string) ($table->area?->name ?? ''),
                    'capacity' => (int) ($table->capacity ?? 0),
                    'status' => $occupied ? 'occupied' : 'available',
                    'available' => ! $occupied,
                    'status_label' => $occupied ? 'مشغولة' : 'متاحة',
                    'occupied_since' => $table->activeSession?->opened_at?->toIso8601String(),
                ];
            })
            ->values();
    }

    private function resolveSelectedTable(
        Collection $tables,
        string $table
    ): ?array {
        $table = trim($table);

        if ($table === '') {
            return null;
        }

        $selected = $tables->first(function (array $candidate) use ($table): bool {
            return (string) $candidate['id'] === $table
                || strcasecmp((string) $candidate['code'], $table) === 0;
        });

        if (! is_array($selected) || ! ($selected['available'] ?? false)) {
            return null;
        }

        return $selected;
    }

    private function serviceOptions(): array
    {
        return collect([
            [
                'value' => RestaurantServiceType::DineIn->value,
                'label' => RestaurantServiceType::DineIn->label(),
                'enabled' => (bool) SystemSetting::get(
                    'customer_menu_allow_dine_in',
                    true
                ),
            ],
            [
                'value' => RestaurantServiceType::Takeaway->value,
                'label' => RestaurantServiceType::Takeaway->label(),
                'enabled' => (bool) SystemSetting::get(
                    'customer_menu_allow_takeaway',
                    true
                ),
            ],
            [
                'value' => RestaurantServiceType::Delivery->value,
                'label' => RestaurantServiceType::Delivery->label(),
                'enabled' => (bool) SystemSetting::get(
                    'customer_menu_allow_delivery',
                    false
                ),
            ],
        ])
            ->where('enabled', true)
            ->values()
            ->all();
    }

    private function teamMembers(Location $location): Collection
    {
        if (! (bool) SystemSetting::get('customer_menu_show_team', false)) {
            return collect();
        }

        $limit = max(
            1,
            min(
                12,
                (int) SystemSetting::get('customer_menu_team_limit', 6)
            )
        );

        return Employee::query()
            ->where('employment_status', 'active')
            ->whereHas(
                'locations',
                fn ($query) => $query->where(
                    'locations.id',
                    (int) $location->id
                )
            )
            ->orderBy('full_name')
            ->limit($limit)
            ->get([
                'id',
                'full_name',
                'profile_image',
                'job_title',
            ])
            ->map(fn (Employee $employee): array => [
                'id' => (int) $employee->id,
                'name' => (string) $employee->full_name,
                'job_title' => trim((string) ($employee->job_title ?? '')),
                'image' => $this->assetFromPath(
                    (string) ($employee->profile_image ?? '')
                ),
            ])
            ->values();
    }

    private function branding(): array
    {
        $nameAr = trim((string) SystemSetting::get('system_name', ''));
        $nameEn = trim((string) SystemSetting::get('system_name_en', ''));

        return [
            'name' => $nameAr !== ''
                ? $nameAr
                : ($nameEn !== '' ? $nameEn : 'المطعم'),
            'nameEn' => $nameEn,
            'tagline' => trim(
                (string) SystemSetting::get('brand_tagline_ar', '')
            ),
            'logoUrl' => $this->assetFromPath(
                (string) SystemSetting::get('brand_logo', '')
            ) ?: $this->assetFromPath(
                (string) SystemSetting::get('brand_logo_small', '')
            ),
            'faviconUrl' => $this->assetFromPath(
                (string) SystemSetting::get('brand_favicon', '')
            ),
            'coverUrl' => $this->assetFromPath(
                (string) SystemSetting::get('customer_menu_cover_image', '')
            ),
            'title' => trim(
                (string) SystemSetting::get(
                    'customer_menu_title',
                    'اطلب مباشرة'
                )
            ),
            'subtitle' => trim(
                (string) SystemSetting::get(
                    'customer_menu_subtitle',
                    'اختر طلبك وسنجهزه لك'
                )
            ),
            'checkoutButtonText' => trim(
                (string) SystemSetting::get(
                    'customer_menu_checkout_button_text',
                    'إرسال الطلب'
                )
            ) ?: 'إرسال الطلب',
            'phone' => trim(
                (string) SystemSetting::get('business_phone', '')
            ),
            'address' => trim(
                (string) SystemSetting::get('business_address', '')
            ),
            'website' => trim(
                (string) SystemSetting::get('business_website', '')
            ),
        ];
    }

    private function theme(): array
    {
        return [
            'primary' => (string) SystemSetting::get(
                'customer_menu_primary_color',
                '#704C34'
            ),
            'accent' => (string) SystemSetting::get(
                'customer_menu_accent_color',
                '#D79A55'
            ),
            'background' => (string) SystemSetting::get(
                'customer_menu_background_color',
                '#F7F3EE'
            ),
            'surface' => (string) SystemSetting::get(
                'customer_menu_surface_color',
                '#FFFFFF'
            ),
            'text' => (string) SystemSetting::get(
                'customer_menu_text_color',
                '#241D18'
            ),
            'muted' => (string) SystemSetting::get(
                'customer_menu_muted_color',
                '#7D746C'
            ),
            'border' => (string) SystemSetting::get(
                'customer_menu_border_color',
                '#E9E1D8'
            ),
            'radius' => max(
                0,
                min(40, (int) SystemSetting::get('customer_menu_radius', 18))
            ),

            // Existing ordering UX
            'showSearch' => (bool) SystemSetting::get(
                'customer_menu_show_search',
                true
            ),
            'showCategories' => (bool) SystemSetting::get(
                'customer_menu_show_categories',
                true
            ),
            'layoutPreset' => (string) SystemSetting::get(
                'customer_menu_layout_preset',
                'storefront'
            ),
            'heroStyle' => (string) SystemSetting::get(
                'customer_menu_hero_style',
                'cover'
            ),
            'heroHeight' => max(
                220,
                min(620, (int) SystemSetting::get('customer_menu_hero_height', 430))
            ),
            'coverOverlay' => max(
                0,
                min(90, (int) SystemSetting::get('customer_menu_cover_overlay', 48))
            ),
            'cardStyle' => (string) SystemSetting::get(
                'customer_menu_card_style',
                'elevated'
            ),
            'cardImageRatio' => (string) SystemSetting::get(
                'customer_menu_card_image_ratio',
                '4-3'
            ),
            'imageFit' => (string) SystemSetting::get(
                'customer_menu_image_fit',
                'cover'
            ),
            'columns' => max(
                2,
                min(5, (int) SystemSetting::get('customer_menu_columns', 3))
            ),
            'categoryStyle' => (string) SystemSetting::get(
                'customer_menu_category_style',
                'pills'
            ),
            'fontFamily' => (string) SystemSetting::get(
                'customer_menu_font_family',
                'Cairo'
            ),
            'showHero' => (bool) SystemSetting::get(
                'customer_menu_show_hero',
                true
            ),
            'showDescriptions' => (bool) SystemSetting::get(
                'customer_menu_show_descriptions',
                true
            ),
            'showCategoryBadge' => (bool) SystemSetting::get(
                'customer_menu_show_category_badge',
                true
            ),

            // V4 experience
            'experiencePreset' => (string) SystemSetting::get(
                'customer_menu_experience_preset',
                'cafe'
            ),
            'introMode' => (string) SystemSetting::get(
                'customer_menu_intro_mode',
                'first_visit'
            ),
            'introTitle' => trim(
                (string) SystemSetting::get(
                    'customer_menu_intro_title',
                    'أهلاً بك'
                )
            ),
            'introSubtitle' => trim(
                (string) SystemSetting::get(
                    'customer_menu_intro_subtitle',
                    'تجربة ألذ تبدأ من هنا'
                )
            ),
            'introCta' => trim(
                (string) SystemSetting::get(
                    'customer_menu_intro_cta',
                    'اطلب الآن'
                )
            ) ?: 'اطلب الآن',
            'introEyebrow' => trim(
                (string) SystemSetting::get(
                    'customer_menu_intro_eyebrow',
                    ''
                )
            ),
            'introShowLogo' => (bool) SystemSetting::get(
                'customer_menu_intro_show_logo',
                true
            ),
            'introAlign' => (string) SystemSetting::get(
                'customer_menu_intro_align',
                'center'
            ),
            'introImage' => $this->assetFromPath(
                (string) SystemSetting::get(
                    'customer_menu_intro_image',
                    ''
                )
            ),
            'navStyle' => (string) SystemSetting::get(
                'customer_menu_nav_style',
                'floating'
            ),
            'contentWidth' => max(
                980,
                min(
                    1700,
                    (int) SystemSetting::get(
                        'customer_menu_content_width',
                        1460
                    )
                )
            ),
            'sectionGap' => max(
                20,
                min(
                    100,
                    (int) SystemSetting::get(
                        'customer_menu_section_gap',
                        42
                    )
                )
            ),
            'productCardRadius' => max(
                0,
                min(
                    40,
                    (int) SystemSetting::get(
                        'customer_menu_product_card_radius',
                        18
                    )
                )
            ),
            'productCardShadow' => (string) SystemSetting::get(
                'customer_menu_product_card_shadow',
                'soft'
            ),
            'showFeatured' => (bool) SystemSetting::get(
                'customer_menu_show_featured',
                true
            ),
            'featuredTitle' => trim(
                (string) SystemSetting::get(
                    'customer_menu_featured_title',
                    'اختياراتنا لك'
                )
            ) ?: 'اختياراتنا لك',
            'featuredLimit' => max(
                2,
                min(
                    8,
                    (int) SystemSetting::get(
                        'customer_menu_featured_limit',
                        4
                    )
                )
            ),
            'showTeam' => (bool) SystemSetting::get(
                'customer_menu_show_team',
                false
            ),
            'teamTitle' => trim(
                (string) SystemSetting::get(
                    'customer_menu_team_title',
                    'طاقمنا'
                )
            ) ?: 'طاقمنا',
            'teamSubtitle' => trim(
                (string) SystemSetting::get(
                    'customer_menu_team_subtitle',
                    'الوجوه التي تصنع تجربتك'
                )
            ),
            'teamCardStyle' => (string) SystemSetting::get(
                'customer_menu_team_card_style',
                'portrait'
            ),
            'showFooter' => (bool) SystemSetting::get(
                'customer_menu_show_footer',
                true
            ),
            'footerText' => trim(
                (string) SystemSetting::get(
                    'customer_menu_footer_text',
                    ''
                )
            ),

            // V5 Showcase
            'showcaseEnabled' => (bool) SystemSetting::get('customer_menu_showcase_enabled', true),
            'showcaseDarkColor' => (string) SystemSetting::get('customer_menu_showcase_dark_color', '#202427'),
            'showcaseEyebrow' => trim((string) SystemSetting::get('customer_menu_showcase_eyebrow', 'تجربة الطلب الجديدة')),
            'showcaseTitle' => trim((string) SystemSetting::get('customer_menu_showcase_title', '')),
            'showcaseSubtitle' => trim((string) SystemSetting::get('customer_menu_showcase_subtitle', '')),
            'showcasePrimaryCta' => trim((string) SystemSetting::get('customer_menu_showcase_primary_cta', 'اطلب الآن')) ?: 'اطلب الآن',
            'showcaseSecondaryCta' => trim((string) SystemSetting::get('customer_menu_showcase_secondary_cta', 'استكشف المنيو')) ?: 'استكشف المنيو',
            'showcaseHeight' => max(560, min(900, (int) SystemSetting::get('customer_menu_showcase_height', 700))),
            'showcaseDiagonalDepth' => max(40, min(180, (int) SystemSetting::get('customer_menu_showcase_diagonal_depth', 105))),
            'showcaseShowInfoCards' => (bool) SystemSetting::get('customer_menu_showcase_show_info_cards', true),
            'showcaseShowCategoryStrip' => (bool) SystemSetting::get('customer_menu_showcase_show_category_strip', true),
        ];
    }

    private function guessCategoryIcon(?string $text): string
    {
        $text = mb_strtolower(trim((string) $text));

        return match (true) {
            str_contains($text, 'برغر'), str_contains($text, 'برجر'), str_contains($text, 'burger') => 'burger',
            str_contains($text, 'بيتزا'), str_contains($text, 'pizza') => 'pizza',
            str_contains($text, 'قهوة'), str_contains($text, 'coffee'), str_contains($text, 'كافيه') => 'coffee',
            str_contains($text, 'كيك'), str_contains($text, 'جاتوه'), str_contains($text, 'cake') => 'cake',
            str_contains($text, 'كرواسون'), str_contains($text, 'مخبوز'), str_contains($text, 'croissant') => 'croissant',
            str_contains($text, 'دونات'), str_contains($text, 'donut') => 'donut',
            str_contains($text, 'ايس كريم'), str_contains($text, 'آيس كريم'), str_contains($text, 'ice') => 'icecream',
            str_contains($text, 'عصير'), str_contains($text, 'juice') => 'juice',
            str_contains($text, 'مشروب'), str_contains($text, 'drink') => 'drink',
            str_contains($text, 'بطاط'), str_contains($text, 'fries') => 'fries',
            str_contains($text, 'دجاج'), str_contains($text, 'chicken') => 'chicken',
            str_contains($text, 'سلط'), str_contains($text, 'salad') => 'salad',
            str_contains($text, 'ساند'), str_contains($text, 'sandwich') => 'sandwich',
            str_contains($text, 'شوكولات'), str_contains($text, 'chocolate') => 'chocolate',
            str_contains($text, 'شاي'), str_contains($text, 'tea') => 'tea',
            str_contains($text, 'فطور'), str_contains($text, 'breakfast') => 'breakfast',
            str_contains($text, 'هدية'), str_contains($text, 'هدايا'), str_contains($text, 'gift') => 'gift',
            str_contains($text, 'حلويات'), str_contains($text, 'حلو'), str_contains($text, 'dessert') => 'dessert',
            default => 'sparkles',
        };
    }

    private function assetFromPath(?string $path): ?string
    {
        $path = trim((string) $path);

        if ($path === '') {
            return null;
        }

        if (
            str_starts_with($path, 'http://')
            || str_starts_with($path, 'https://')
            || str_starts_with($path, '//')
        ) {
            return $path;
        }

        $normalized = ltrim(
            str_replace('\\', '/', $path),
            '/'
        );

        if (str_starts_with($normalized, 'storage/')) {
            return asset($normalized);
        }

        if (file_exists(public_path($normalized))) {
            return asset($normalized);
        }

        return asset('storage/' . $normalized);
    }
}
